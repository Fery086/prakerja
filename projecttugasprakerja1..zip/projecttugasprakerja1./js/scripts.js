window.addEventListener('DOMContentLoaded', event => {

    // function untuk menyusutkan navbar
    var susutNavbar = function () {
        const navbarCollapsible = document.body.querySelector('#NavbarUtama');
        if (!navbarCollapsible) {
            return;
        }
        if (window.scrollY === 0) {
            navbarCollapsible.classList.remove('navbar-shrink')
        } else {
            navbarCollapsible.classList.add('navbar-shrink')
        }

    };

    // Menyusutkan navbar 
    susutNavbar();

    // Menyusutkan navbar ketika halaman di scrol
    document.addEventListener('scroll', susutNavbar);

    // Aktifkan scrollspy Bootstrap di elemen navbar utama
    const NavbarUtama = document.body.querySelector('#NavbarUtama');
    if (NavbarUtama) {
        new bootstrap.ScrollSpy(document.body, {
            target: '#NavbarUtama',
            offset: 74,
        });
    };

    // Ciutkan ataucollapse navbar responsif ketika toggler terlihat
    const navbarToggler = document.body.querySelector('.navbar-toggler');
    const responsiveNavItems = [].slice.call(
        document.querySelectorAll('#responNavbar .nav-link')
    );
    responsiveNavItems.map(function (responsiveNavItem) {
        responsiveNavItem.addEventListener('click', () => {
            if (window.getComputedStyle(navbarToggler).display !== 'none') {
                navbarToggler.click();
            }
        });
    });

});